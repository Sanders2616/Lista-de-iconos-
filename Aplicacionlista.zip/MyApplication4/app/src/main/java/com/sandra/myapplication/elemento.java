package com.sandra.myapplication;

public class elemento {

    private String Nombre;
    private String descripcion;
    private int imagen;

    public elemento(String Nombre, String descripcion, int imagen) {

        this.Nombre = Nombre;
        this.descripcion = descripcion;
        this.imagen = imagen;
    }



    public int getImagen() {
        return imagen;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getdescripcion() {
        return descripcion;
    }


}