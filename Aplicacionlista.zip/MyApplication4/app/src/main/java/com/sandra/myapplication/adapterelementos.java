package com.sandra.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.List;

public class adapterelementos extends ArrayAdapter<elemento> {

    List<elemento> listaelementos;

    public adapterelementos(@NonNull Context context, int resource, @NonNull List<elemento> objects) {
        super(context, resource, objects);
        listaelementos = objects;
    }


    @NonNull
    @Override


    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = convertView;
        elemento elementoactual = listaelementos.get(position);
        if(view == null){


            view = LayoutInflater.from(getContext()).inflate(R.layout.vistaelementos, parent );

        }
        ImageView icono = view.findViewById(R.id.imgelemento);
        icono.setImageResource(elementoactual.getImagen());

        TextView Nombre = view.findViewById(R.id.Nombre);
        Nombre.setText(elementoactual.getNombre());

        TextView descripcion = view.findViewById(R.id.descripcion);
        descripcion.setText(elementoactual.getdescripcion());

return view;
    }
}
