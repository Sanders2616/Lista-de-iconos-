package com.sandra.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {


    private ArrayList<elemento> listaelementos;
    private adapterelementos adapterelementos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       listaelementos  = new ArrayList<>();

        listaelementos.add(new elemento("Conexiones"," wi-fi,Bluetooth,Perfil fuera de linea,Uso de datos",R.drawable.senal_wifi));
        listaelementos.add(new elemento("Sonido y Vibracion","Modo de sonido,Tono de llamada",R.drawable.sonido_encendido));
        listaelementos.add(new elemento("Notificaciónes","Notificaciónes de aplicaciones,Barra de estado",R.drawable.activar_el_boton_de_notificaciones));
        listaelementos.add(new elemento("Pantalla","Brillo,Filtro de luz,Pantalla de inicio",R.drawable.simbolo_de_configuracion_del_telefono_movil_en_la_pantalla));
        listaelementos.add(new elemento("Fondo de pantalla","Fondo de pantalla,Suspender,Tamaño de letra",R.drawable.fondo_de_pantalla));
        listaelementos.add(new elemento("Temas","Temas,Fondos de pantalla,Fondo de pantalla de bloqueo",R.drawable.tema));
        listaelementos.add(new elemento("Datos biométricos y seguridad","Reconocimiento facial,Huellas digitales,Localización movil",R.drawable.proteger));
        listaelementos.add(new elemento("Ubicación","Ajustes de ubicación,Solicitud de ubicación",R.drawable.pin_de_ubicacion));
        listaelementos.add(new elemento("Actualización de software","Descargar actualizaciones,última actualización instalada",R.drawable.actualizacion_del_sistema));


        com.sandra.myapplication.adapterelementos adapterelementos = new adapterelementos(getApplicationContext(), 0, listaelementos);
        ListView listview = findViewById(R.id.Listviewelementos);
        listview.setAdapter(adapterelementos);
    }

}